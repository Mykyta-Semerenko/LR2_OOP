using System;
using System.Drawing;
using System.Windows.Forms;

namespace DvovymirniMasivy;

public class frmMass : Form
{
    private readonly Label lblN = new();
    private readonly Label lblM = new();
    private readonly Label lblResult = new();
    private readonly TextBox txtn = new();
    private readonly TextBox txtm = new();
    private readonly TextBox txtRez = new();
    private readonly DataGridView dgvMass = new();
    private readonly Button cmdStart = new();
    private readonly Button cmdClear = new();
    private readonly Button cmdExit = new();
    private readonly Random rnd = new();

    public frmMass()
    {
        InitializeForm();
        ConfigureControls();
        AddControls();
        cmdStart.Click += cmdStart_Click;
        cmdClear.Click += cmdClear_Click;
        cmdExit.Click += cmdExit_Click;
    }

    private void InitializeForm()
    {
        Text = "Двовимірні масиви";
        Name = "frmMass";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(850, 570);
        Size = new Size(1050, 680);
        Font = new Font("Segoe UI", 11F);
        BackColor = SystemColors.Control;
    }

    private void ConfigureControls()
    {
        lblN.Text = "Количество строк n=";
        lblM.Text = "Количество столбцов m=";
        lblResult.Text = "Результат:";
        ConfigureLabel(lblN, 20, 22, 260);
        ConfigureLabel(lblM, 20, 112, 280);
        ConfigureLabel(lblResult, 20, 202, 260);

        ConfigureTextBox(txtn, "txtn", 20, 52, 250, 32);
        ConfigureTextBox(txtm, "txtm", 20, 142, 250, 32);
        ConfigureTextBox(txtRez, "txtRez", 20, 232, 365, 190);
        txtRez.Multiline = true;
        txtRez.ReadOnly = true;
        txtRez.ScrollBars = ScrollBars.Vertical;
        txtRez.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Bottom;

        dgvMass.Name = "dgvMass";
        dgvMass.Location = new Point(410, 22);
        dgvMass.Size = new Size(600, 510);
        dgvMass.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        dgvMass.BackgroundColor = Color.DarkGray;
        dgvMass.BorderStyle = BorderStyle.Fixed3D;
        dgvMass.AllowUserToAddRows = false;
        dgvMass.AllowUserToDeleteRows = false;
        dgvMass.AllowUserToResizeRows = false;
        dgvMass.RowHeadersWidth = 45;
        dgvMass.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
        dgvMass.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        dgvMass.SelectionMode = DataGridViewSelectionMode.CellSelect;
        dgvMass.MultiSelect = false;

        ConfigureButton(cmdStart, "cmdStart", "Вычислить", 20, 555, 250);
        ConfigureButton(cmdClear, "cmdClear", "Очистка полей", 380, 555, 250);
        ConfigureButton(cmdExit, "cmdExit", "Завершить работу", 740, 555, 270);

        cmdStart.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        cmdClear.Anchor = AnchorStyles.Bottom;
        cmdExit.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    }

    private static void ConfigureLabel(Label label, int x, int y, int width)
    {
        label.Location = new Point(x, y);
        label.Size = new Size(width, 28);
        label.AutoSize = false;
    }

    private static void ConfigureTextBox(TextBox box, string name, int x, int y, int width, int height)
    {
        box.Name = name;
        box.Location = new Point(x, y);
        box.Size = new Size(width, height);
        box.Font = new Font("Segoe UI", 11F);
    }

    private static void ConfigureButton(Button button, string name, string text, int x, int y, int width)
    {
        button.Name = name;
        button.Text = text;
        button.Location = new Point(x, y);
        button.Size = new Size(width, 42);
        button.Font = new Font("Segoe UI", 10.5F);
    }

    private void AddControls()
    {
        Controls.AddRange(new Control[]
        {
            lblN, lblM, lblResult, txtn, txtm, txtRez,
            dgvMass, cmdStart, cmdClear, cmdExit
        });
    }

    private void cmdStart_Click(object? sender, EventArgs e)
    {
        if (!int.TryParse(txtn.Text, out int n) ||
            !int.TryParse(txtm.Text, out int m) ||
            n <= 0 || m <= 0)
        {
            MessageBox.Show(
                "Введіть додатні цілі числа для кількості рядків і стовпців.",
                "Помилка введення",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return;
        }

        if (n > 100 || m > 100)
        {
            MessageBox.Show(
                "Для зручного відображення введіть не більше 100 рядків і 100 стовпців.",
                "Завеликий розмір",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return;
        }

        int[,] A = new int[n, m];
        int countPositive = 0;
        long sumPositive = 0;

        dgvMass.Rows.Clear();
        dgvMass.Columns.Clear();
        dgvMass.ColumnCount = m;
        dgvMass.RowCount = n;

        for (int j = 0; j < m; j++)
        {
            dgvMass.Columns[j].Name = $"Стовпець {j + 1}";
            dgvMass.Columns[j].Width = 55;
            dgvMass.Columns[j].SortMode = DataGridViewColumnSortMode.NotSortable;
        }

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < m; j++)
            {
                A[i, j] = rnd.Next(-50, 50);
                dgvMass.Rows[i].Cells[j].Value = A[i, j];

                if (A[i, j] > 0)
                {
                    sumPositive += A[i, j];
                    countPositive++;
                }
            }
        }

        if (countPositive > 0)
        {
            double average = (double)sumPositive / countPositive;
            txtRez.Text =
                "Середнє арифметичне = " + Math.Round(average, 5) +
                Environment.NewLine +
                "Кількість додатних елементів = " + countPositive;
        }
        else
        {
            txtRez.Text =
                "Додатних елементів немає." + Environment.NewLine +
                "Кількість додатних елементів = 0";
        }
    }

    private void cmdClear_Click(object? sender, EventArgs e)
    {
        txtn.Clear();
        txtm.Clear();
        txtRez.Clear();
        dgvMass.Rows.Clear();
        dgvMass.Columns.Clear();
        txtn.Focus();
    }

    private void cmdExit_Click(object? sender, EventArgs e)
    {
        Close();
    }
}
